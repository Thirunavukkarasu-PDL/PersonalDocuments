import { ref } from "vue";

const API_URL = "https://jsonplaceholder.typicode.com/todos";

export const useTodos = () => {
  const todos = ref([]);
  const loading = ref(false);
  const error = ref(null);

  const fetchTodos = async (searchId?: number) => {
    loading.value = true;
    try {
      // console.log("searchId: ", searchId);
      if (searchId) {
        const response = await fetch(`${API_URL}/${searchId}`);
        const todo = await response.json();
        todos.value = [todo];
      } else {
        const response = await fetch(API_URL);
        todos.value = await response.json();
      }
    } catch (err) {
      error.value = err;
      todos.value = [];
    } finally {
      // console.log("todos.value: ", todos.value.length);
      loading.value = false;
    }
  };

  const addTodo = async (todo) => {
    // console.log("todo: ", JSON.stringify(todo));
    loading.value = true;
    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(todo),
      });
      const newTodo = await response.json();
      newTodo.id = Date.now();
      todos.value.unshift(newTodo);
      // console.log("newTodo: ====>", JSON.stringify(newTodo));
    } catch (err) {
      console.error("Add operation failed:", err);
      error.value = err;
    } finally {
      loading.value = false;
    }
  };

  const updateTodo = async (id, updatedData) => {
    console.log("id: ", id);
    console.log("updatedData: ", JSON.stringify(updatedData));
    loading.value = true;
    try {
      const original = todos.value.find((t) => t.id === id);
      if (!original) throw new Error("Todo not found");

      const fullData = {
        id,
        userId: original.userId,
        title: updatedData.title ?? original.title,
        completed: updatedData.completed ?? original.completed,
      };

      console.log("fullData: ", fullData);

      const response = await fetch(`${API_URL}/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(fullData),
      });

      const updatedTodo = await response.json();

      const index = todos.value.findIndex((t) => t.id === id);
      if (index !== -1) {
        todos.value[index] = updatedTodo;
      }
    } catch (err) {
      console.error("Update failed:", err);
      error.value = err;
    } finally {
      loading.value = false;
    }
  };

  const deleteTodo = async (id) => {
    loading.value = true;
    try {
      await fetch(`${API_URL}/${id}`, { method: "DELETE" });
      todos.value = todos.value.filter((t) => t.id !== id);
    } catch (err) {
      console.error("Delete operation failed:", err);
      error.value = err;
    } finally {
      loading.value = false;
    }
  };

  return {
    todos,
    loading,
    error,
    fetchTodos,
    addTodo,
    updateTodo,
    deleteTodo,
  };
};
