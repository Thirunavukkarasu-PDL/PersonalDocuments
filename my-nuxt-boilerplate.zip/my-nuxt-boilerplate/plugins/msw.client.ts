import { setupWorker } from "msw/browser";
import { handlers } from "~/mocks/handlers";

export default defineNuxtPlugin(() => {
  if (process.client) {
    const worker = setupWorker(...handlers);
    worker.start();
  }
});
