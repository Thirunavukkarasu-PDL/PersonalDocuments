// server/api/users.js
export default defineEventHandler(() => {
  return [
    { id: 1, name: "Alice" },
    { id: 2, name: "Bob" },
  ];
});
