<template>
  <div class="space-y-4">
    <BaseInput
      id="email"
      label="Email"
      type="email"
      v-model="form.email"
      :error="errors.email"
    />
    <BaseInput
      id="password"
      label="Password"
      type="password"
      v-model="form.password"
      :error="errors.password"
    />
  </div>
</template>

<script setup>
import BaseInput from "../../components/atoms/BaseInput.vue";
defineProps(["form", "errors"]);
</script>
