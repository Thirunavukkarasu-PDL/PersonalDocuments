// stories/molecules/RegistrationFields.stories.ts

import RegistrationFields from "./RegistrationFields.vue";

export default {
  title: "Molecules/RegistrationFields",
  component: RegistrationFields,
  args: {
    form: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
    errors: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  },
};

export const Default = {};

export const WithErrors = {
  args: {
    form: {
      name: "",
      email: "invalidemail",
      password: "123",
      confirmPassword: "456",
    },
    errors: {
      name: "Name is required",
      email: "Email is empty or invalid",
      password: "Password is empty or too short (atleast 5 characters)",
      confirmPassword: "Passwords do not match",
    },
  },
};
