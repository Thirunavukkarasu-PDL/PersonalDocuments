import LoginFields from "./LoginFields.vue";

export default {
  title: "Molecules/LoginFields",
  component: LoginFields,
};

export const Default = {
  args: {
    form: {
      email: "",
      password: "",
    },
    errors: {
      email: "",
      password: "",
    },
  },
};

export const WithErrors = {
  args: {
    form: {
      email: "wrong email",
      password: "",
    },
    errors: {
      email: "Email is empty or invalid",
      password: "Password is required",
    },
  },
};
