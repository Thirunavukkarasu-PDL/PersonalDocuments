<template>
  <div class="space-y-4">
    <BaseInput
      id="name"
      label="Name"
      v-model="form.name"
      :error="errors.name"
    />
    <BaseInput
      id="email"
      label="Email"
      type="email"
      v-model="form.email"
      :error="errors.email"
    />
    <BaseInput
      id="password"
      label="Password"
      type="password"
      v-model="form.password"
      :error="errors.password"
    />
    <BaseInput
      id="confirmPassword"
      label="Confirm Password"
      type="password"
      v-model="form.confirmPassword"
      :error="errors.confirmPassword"
    />
  </div>
</template>

<script setup>
import BaseInput from "../../components/atoms/BaseInput.vue";
defineProps(["form", "errors"]);
</script>
