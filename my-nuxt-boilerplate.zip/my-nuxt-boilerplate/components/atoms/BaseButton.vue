<script setup lang="ts">
import { computed } from "vue";

const props = defineProps<{
  type: "primary" | "secondary";
  isDisabled?: boolean;
  label: string;
  onClick: (event: MouseEvent, message: string) => void;
}>();

function handleClick(event: MouseEvent) {
  const message = `${props.label} button clicked`;
  console.log(message);
  props.onClick(event, message);
}

const buttonClass = computed(() => {
  return `${props.type}-large-btn`;
});
</script>

<template>
  <button
    :class="['storybook-button', buttonClass]"
    :disabled="isDisabled"
    @click="handleClick"
  >
    {{ label }}
  </button>
</template>

<style scoped>
/* Common styles */
button {
  padding: 12px 20px;
  border: none;
  border-radius: 9999px;
  overflow: hidden;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  min-width: 100px;
  width: auto;
  cursor: pointer;
  font-size: 12px;
  font-family: "Inter", sans-serif;
  font-weight: 600;
  text-transform: uppercase;
  line-height: 16px;
  letter-spacing: 0.6px;
}

/* Primary styles */
.primary-large-btn {
  background: var(--color-buttons-primary-default-background-enable, #004c9c);
  color: var(--color-buttons-primary-default-foreground-content-enable, #fff);
}

/* Hover */
.primary-large-btn:hover:not(:disabled) {
  background: var(--color-buttons-primary-default-background-hover, #002e5e);
  color: var(--color-buttons-primary-default-foreground-content-hover, #fff);
}

/* Active */
.primary-large-btn:active:not(:disabled) {
  background: var(--color-buttons-primary-default-background-press, #303030);
  color: var(--color-buttons-primary-default-foreground-content-press, #fff);
}

/* Focus */
.primary-large-btn:focus-visible {
  outline: 2px solid
    var(--color-buttons-primary-default-foreground-border-focus, #454545);
  outline-offset: -2px;
  background: var(--color-buttons-primary-default-background-focus, #fff);
  color: var(--color-buttons-primary-default-foreground-content-focus, #004c9c);
}

/* Disabled */
.primary-large-btn:disabled {
  background: var(--color-buttons-primary-default-background-disable, #e0e0e0);
  color: var(
    --color-buttons-primary-default-foreground-content-disable,
    #b7b7b7
  );
  cursor: not-allowed;
}

/* Secondary styles */
.secondary-large-btn {
  background: var(
    --color-buttons-secondary-default-background-enable,
    rgba(255, 255, 255, 0)
  );
  color: var(
    --color-buttons-secondary-default-foreground-content-enable,
    #004c9c
  );
  outline: 1px solid
    var(--color-buttons-secondary-default-foreground-border-enable, #99b7d7);
  outline-offset: -1px;
}

.secondary-large-btn:hover:not(:disabled) {
  background: var(--color-buttons-secondary-default-background-hover, #002e5e);
  color: var(--color-buttons-secondary-default-foreground-content-hover, #fff);
  outline: none;
}

.secondary-large-btn:active:not(:disabled) {
  background: var(--color-buttons-secondary-default-background-press, #303030);
  color: var(--color-buttons-secondary-default-foreground-content-press, #fff);
  outline: none;
}

.secondary-large-btn:focus-visible {
  outline: 2px solid
    var(--color-buttons-secondary-default-foreground-border-focus, #454545);
  outline-offset: -2px;
}

.secondary-large-btn:disabled {
  background: var(
    --color-buttons-secondary-default-background-disable,
    rgba(255, 255, 255, 0)
  );
  color: var(
    --color-buttons-secondary-default-foreground-content-disable,
    #b7b7b7
  );
  cursor: not-allowed;
  outline: 1px solid
    var(--color-buttons-secondary-default-foreground-border-disable, #d6d6d6);
  outline-offset: -1px;
}
</style>
