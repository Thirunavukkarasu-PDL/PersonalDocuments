import BaseInput from "./BaseInput.vue";

export default {
  title: "Atoms/BaseInput",
  component: BaseInput,
  argTypes: {
    modelValue: { control: "text" },
    label: { control: "text" },
    type: {
      control: { type: "select" },
      options: ["text", "email", "password", "number"],
    },
    error: { control: "text" },
    id: { control: "text" },
  },
};

const Template = (args) => ({
  components: { BaseInput },
  setup() {
    return { args };
  },
  template: `<BaseInput v-bind="args" />`,
});

export const Default = Template.bind({});
Default.args = {
  id: "name",
  label: "Name",
  type: "text",
  modelValue: "",
};

export const WithError = Template.bind({});
WithError.args = {
  id: "email",
  label: "Email",
  type: "email",
  modelValue: "",
  error: "This field is required",
};
