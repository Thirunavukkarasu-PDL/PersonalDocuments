<template>
  <div class="input-wrapper">
    <label :for="id" class="input-label">
      {{ label }}
    </label>

    <input
      :id="id"
      :type="type"
      :value="modelValue"
      @input="$emit('update:modelValue', $event.target.value)"
      class="input-field"
    />
  </div>
  <p v-if="error" class="error-message">{{ error }}</p>
</template>

<script setup>
defineProps({
  id: String,
  label: String,
  type: {
    type: String,
    default: "text",
  },
  modelValue: String,
  error: String,
});

defineEmits(["update:modelValue"]);
</script>

<style scoped>
.input-wrapper {
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
}

.input-wrapper:has(+ .error-message) {
  margin-bottom: 0; /* remove margin if error exists */
}

.error-message {
  color: red;
  font-size: 14px;
  margin-left: 170px;
}

.input-label {
  width: 150px;
  font-size: 1rem;
  font-weight: 500;
  color: #333;
  margin-right: 1rem;
}

.input-field {
  width: 300px;
  padding: 0.5rem 0.75rem;
  border: 1px solid #ccc;
  border-radius: 0.375rem;
  font-size: 1rem;
  color: #222;
  background-color: #fff;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
  transition: border-color 0.2s, box-shadow 0.2s;
}

.input-field:focus {
  outline: none;
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.3);
}
</style>
