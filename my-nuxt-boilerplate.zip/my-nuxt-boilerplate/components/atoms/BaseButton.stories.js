import BaseButton from "../atoms/BaseButton.vue";

export default {
  title: "Atoms/BaseButton",
  component: BaseButton,
  argTypes: {
    type: {
      control: { type: "select" },
      options: ["primary", "secondary"],
    },
    isDisabled: { control: "boolean" },
    label: { control: "text" },
    onClick: { action: "clicked" },
  },
};

const Template = (args) => ({
  components: { BaseButton },
  setup() {
    return { args };
  },
  template: '<BaseButton v-bind="args" />',
});

export const Primary = Template.bind({});
Primary.args = {
  type: "primary",
  label: "Primary",
  isDisabled: false,
};

export const Secondary = Template.bind({});
Secondary.args = {
  type: "secondary",
  label: "Secondary",
  isDisabled: false,
};

export const Disabled = Template.bind({});
Disabled.args = {
  type: "primary",
  label: "Disabled",
  isDisabled: true,
};
