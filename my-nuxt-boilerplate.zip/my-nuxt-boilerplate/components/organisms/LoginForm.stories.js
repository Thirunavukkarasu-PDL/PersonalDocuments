import { onMounted } from "vue";
import LoginForm from "./LoginForm.vue";
import { useRouter } from "vue-router";

export default {
  title: "Organisms/LoginForm",
  component: LoginForm,
  parameters: {
    layout: "fullscreen",
  },
};

export const Default = () => ({
  components: { LoginForm },
  setup() {
    const router = useRouter();

    onMounted(() => {
      router.push("/login");
    });

    return {};
  },
  template: `<LoginForm />`,
});
