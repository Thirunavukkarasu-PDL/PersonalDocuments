import { onMounted } from "vue";
import RegistrationForm from "./RegistrationForm.vue";
import { useRouter } from "vue-router";

export default {
  title: "Organisms/RegistrationForm",
  component: RegistrationForm,
  parameters: {
    layout: "fullscreen",
  },
};

export const Default = () => ({
  components: { RegistrationForm },
  setup() {
    const router = useRouter();

    onMounted(() => {
      router.push("/register");
    });

    return {};
  },
  template: `<RegistrationForm />`,
});
