<template>
  <form class="auth-form">
    <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
    <h1 class="form-header">User Registration</h1>

    <RegistrationFields :form="form" :errors="errors" />

    <BaseButton
      type="primary"
      :isDisabled="false"
      label="Submit"
      :onClick="handleSubmit"
    />

    <p :class="formFooterClassName">
      {{ formFooterMessage }}
      Click here to <span class="link" @click="goToLogin">Login</span>
    </p>
  </form>
</template>

<script setup lang="ts">
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import BaseButton from "../../components/atoms/BaseButton.vue";
import RegistrationFields from "../../components/molecules/RegistrationFields.vue";

const router = useRouter();

const errorMessage = ref("");
const formFooterMessage = ref("Already have an account?");
const formFooterClassName = ref("form-footer");

const form = reactive({
  name: "",
  email: "",
  password: "",
  confirmPassword: "",
});

const errors = reactive({
  name: "",
  email: "",
  password: "",
  confirmPassword: "",
});

const validate = () => {
  let isValid = true;
  errors.name = form.name ? "" : "Name is required";

  errors.email = /\S+@\S+\.\S+/.test(form.email)
    ? ""
    : "Email is empty or invalid";

  errors.password =
    form.password.length >= 5
      ? ""
      : "Password is empty or too short (atleast 5 characters)";

  errors.confirmPassword =
    form.confirmPassword === form.password ? "" : "Passwords do not match";

  if (
    errors.name ||
    errors.email ||
    errors.password ||
    errors.confirmPassword
  ) {
    isValid = false;
  }
  return isValid;
};

function goToLogin() {
  router.push("/login");
}

const handleSubmit = (event: MouseEvent, message: string) => {
  console.log(message + " in Registration Form");
  event.preventDefault();

  if (!validate()) return;

  const users = JSON.parse(localStorage.getItem("users") || "[]");
  const user = users.find((u) => u.email === form.email);

  if (!user) {
    users.push({ ...form });
    localStorage.setItem("users", JSON.stringify(users));
    errorMessage.value = "";
    formFooterMessage.value = "User created successfully!";
    formFooterClassName.value = "success-message";
  } else {
    errorMessage.value = "User already exists!";
  }
};
</script>

<style scoped>
.auth-form :deep(button) {
  display: block;
  margin: 20px auto 0;
}

.success-message {
  color: #2e7d32; /* dark green */
  background-color: #e8f5e9; /* light green background */
  padding: 0.75rem 1rem;
  border: 1px solid #c8e6c9;
  border-radius: 0.5rem;
  font-weight: 500;
  margin: 1rem 0;
}
</style>
