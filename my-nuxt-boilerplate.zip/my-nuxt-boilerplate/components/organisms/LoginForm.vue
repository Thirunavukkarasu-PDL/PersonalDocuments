<template>
  <form class="auth-form">
    <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
    <h1 class="form-header">User Login</h1>
    <LoginFields :form="form" :errors="errors" />

    <BaseButton
      type="primary"
      :isDisabled="false"
      label="Submit"
      :onClick="handleSubmit"
    />

    <p class="form-footer">
      Don’t have an account?
      <span class="link" @click="goToRegister">Register</span>
    </p>
  </form>
</template>

<script setup lang="ts">
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import BaseButton from "../../components/atoms/BaseButton.vue";
import LoginFields from "../../components/molecules/LoginFields.vue";

const router = useRouter();
const errorMessage = ref("");

const form = reactive({
  email: "",
  password: "",
});

const errors = reactive({
  email: "",
  password: "",
});

const validate = () => {
  let isValid = true;
  errors.email = /\S+@\S+\.\S+/.test(form.email)
    ? ""
    : "Email is empty or invalid";
  errors.password = form.password ? "" : "Password is required";

  if (errors.email || errors.password) {
    isValid = false;
  }
  return isValid;
};

const handleSubmit = (event: MouseEvent, message: string) => {
  console.log(message + " in Login Form");
  event.preventDefault();

  if (!validate()) return;

  const users = JSON.parse(localStorage.getItem("users") || "[]");
  // console.log("users: ", JSON.stringify(users));

  const user = users.find(
    (u) => u.email === form.email && u.password === form.password
  );

  if (user) {
    sessionStorage.setItem("loggedInUser", JSON.stringify(user));
    router.push("/todos");
  } else {
    errorMessage.value = "Invalid email or password";
  }
};

function goToRegister() {
  router.push("/register");
}
</script>

<style scoped>
.auth-form :deep(button) {
  display: block;
  margin: 20px auto 0;
}
</style>
