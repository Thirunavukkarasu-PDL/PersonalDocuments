<!-- components/StoryRouterWrapper.vue -->
<template>
  <router-view />
</template>
