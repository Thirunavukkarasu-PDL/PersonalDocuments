<template>
  <div class="user-welcome">
    <h2>Welcome, {{ loggedInUser.name }}</h2>
  </div>
  <div>
    <h1>Todos</h1>

    <!-- Action Bar -->
    <div class="action-bar">
      <!-- Search Section -->
      <div class="action-group search-group">
        <input
          v-model="searchId"
          class="input-large"
          placeholder="Enter Todo ID"
        />
        <BaseButton
          type="primary"
          :isDisabled="isDisabled"
          label="Search"
          :onClick="findTodo"
        />
      </div>

      <!-- Add Section -->
      <div class="action-group add-group">
        <input v-model="newTitle" class="input-large" placeholder="New Todo" />
        <BaseButton
          type="primary"
          :isDisabled="newTitle == ''"
          label="Add"
          :onClick="handleAdd"
        />
      </div>
    </div>

    <!-- Loading Indicator -->
    <div v-if="loading">Loading...</div>

    <!-- Todos Table -->
    <table v-else class="todo-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Completed</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(todo, i) in paginatedTodos" :key="todo.id">
          <td>{{ i + 1 }}</td>
          <td>
            <div v-if="editingId === todo.id">
              <input v-model="editTitle" class="input-large" />
            </div>
            <div v-else>
              {{ todo.title }}
            </div>
          </td>
          <td>
            <input
              type="checkbox"
              v-model="todo.completed"
              @change="handleUpdate(todo)"
            />
          </td>
          <td>
            <div v-if="editingId === todo.id">
              <BaseButton
                type="secondary"
                :isDisabled="false"
                label="Save"
                :onClick="(msg) => saveEdit(msg, todo)"
              />
              <BaseButton
                type="secondary"
                :isDisabled="false"
                label="Cancel"
                :onClick="cancelEdit"
              />
            </div>
            <div v-else>
              <BaseButton
                type="secondary"
                :isDisabled="false"
                label="Edit"
                :onClick="(msg) => startEdit(msg, todo)"
              />
              <BaseButton
                type="secondary"
                :isDisabled="false"
                label="Delete"
                :onClick="(msg) => handleDelete(msg, todo.id)"
              />
            </div>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Pagination Controls -->
    <div class="pagination" v-if="totalPages > 1">
      <BaseButton
        type="secondary"
        :isDisabled="currentPage === 1"
        label="Prev"
        :onClick="(msg) => goToPage(msg, currentPage - 1)"
      />
      <span>Page {{ currentPage }} of {{ totalPages }}</span>
      <BaseButton
        type="secondary"
        :isDisabled="currentPage === totalPages"
        label="Next"
        :onClick="(msg) => goToPage(msg, currentPage + 1)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from "vue";
import { useTodos } from "../composables/useTodos";
import BaseButton from "../components/atoms/BaseButton.vue";

const { todos, loading, fetchTodos, addTodo, updateTodo, deleteTodo } =
  useTodos();

const newTitle = ref("");
const editingId = ref<number | null>(null);
const editTitle = ref("");
const searchId = ref("");
const isDisabled = ref(false);
let loggedInUser = reactive({});

// Pagination
const currentPage = ref(1);
const pageSize = ref(5);

const paginatedTodos = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value;
  return todos.value.slice(start, start + pageSize.value);
});

const totalPages = computed(() => {
  return Math.ceil(todos.value.length / pageSize.value);
});

const goToPage = (message: string, page: number) => {
  console.log(message + " in Todos Component");
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page;
  }
};

onMounted(() => {
  loggedInUser = JSON.parse(sessionStorage.getItem("loggedInUser") || "{}");
  fetchTodos(searchId.value);
});

const findTodo = (message: string) => {
  console.log(message + " in Todos Component");
  fetchTodos(searchId.value);
  currentPage.value = 1;
};

const handleAdd = (message: string) => {
  console.log(message + " in Todos Component");
  if (newTitle.value.trim()) {
    addTodo({ title: newTitle.value, completed: false });
    newTitle.value = "";
    currentPage.value = 1;
  }
};

const handleUpdate = (todo: any) => {
  updateTodo(todo.id, { ...todo });
};

const handleDelete = (message: string, id: number) => {
  console.log(message + " in Todos Component");
  deleteTodo(id);
};

const startEdit = (message: string, todo: any) => {
  console.log(message + " in Todos Component");
  editingId.value = todo.id;
  editTitle.value = todo.title;
};

const cancelEdit = (message: string) => {
  if (message) {
    console.log(message + " in Todos Component");
  }

  editingId.value = null;
  editTitle.value = "";
};

const saveEdit = (message: string, todo: any) => {
  console.log(message + " in Todos Component");
  if (editTitle.value.trim()) {
    updateTodo(todo.id, { ...todo, title: editTitle.value });
    cancelEdit();
  }
};
</script>

<style scoped>
.todo-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
  font-family: Arial, sans-serif;
}

.todo-table th,
.todo-table td {
  border: 1px solid #ddd;
  padding: 0.75rem;
  text-align: left;
}

.todo-table th {
  background-color: #f0f0f0;
}

.todo-table tr:nth-child(even) {
  background-color: #fafafa;
}

.todo-table input[type="checkbox"] {
  transform: scale(1.2);
}

.input-large {
  padding: 0.75rem 1rem;
  font-size: 1rem;
  min-width: 250px;
  border: 1px solid #ccc;
  border-radius: 6px;
}

.action-bar {
  display: flex;
  flex-wrap: wrap;
  /* justify-content: space-between; */
  gap: 1rem;
  margin-bottom: 1rem;
  align-items: center;
}

.action-group {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

.add-group {
  margin-left: auto;
}

.pagination {
  margin-top: 1rem;
  display: flex;
  align-items: center;
  gap: 1rem;
}

.user-welcome {
  font-size: 1rem;
  color: #555;
  font-style: italic;
  text-align: right;
  margin-right: 1rem;
}
</style>
