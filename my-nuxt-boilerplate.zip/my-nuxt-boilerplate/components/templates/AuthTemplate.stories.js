import { onMounted } from "vue";
import StoryRouterWrapper from "../../components/StoryRouterWrapper.vue";
import { useRouter } from "vue-router";

export default {
  title: "Templates/AuthTemplate",
  component: StoryRouterWrapper,
  parameters: {
    layout: "fullscreen",
  },
};

export const Default = () => ({
  components: { StoryRouterWrapper },
  setup() {
    const router = useRouter();

    onMounted(() => {
      router.push("/login");
    });

    return {};
  },
  template: `<StoryRouterWrapper />`,
});
