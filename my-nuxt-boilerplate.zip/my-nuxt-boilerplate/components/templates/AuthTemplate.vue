<template>
  <div class="container">
    <header class="header">
      <h1>Photon</h1>
    </header>

    <main class="main">
      <router-view />
    </main>

    <footer class="footer">
      &copy; {{ new Date().getFullYear() }} My App. All rights reserved.
    </footer>
  </div>
</template>

<style scoped>
.container {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #f9f9f9;
  align-items: center;
}

.header {
  width: 100%;
  padding: 16px 0;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.header h1 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.main {
  flex: 1;
  width: 100%;
  max-width: 400px;
  padding: 24px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.footer {
  width: 100%;
  padding: 16px 0;
  text-align: center;
  font-size: 14px;
  color: #777;
}
</style>
