import { http } from "msw";

export const handlers = [
  http.get("/api/customers", ({ request, params }) => {
    return Response.json([{ id: 1, name: "Mocked User" }]);
  }),
];
