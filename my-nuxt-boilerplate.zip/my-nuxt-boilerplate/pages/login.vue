<template>
  <AuthTemplate>
    <LoginForm />
  </AuthTemplate>
</template>

<script setup>
import AuthTemplate from "~/components/templates/AuthTemplate.vue";
import LoginForm from "~/components/organisms/LoginForm.vue";
</script>
