<template>
  <AuthTemplate>
    <RegistrationForm />
  </AuthTemplate>
</template>

<script setup>
import AuthTemplate from "~/components/templates/AuthTemplate.vue";
import RegistrationForm from "~/components/organisms/RegistrationForm.vue";
</script>
