<template>
  <div>
    <header class="header">
      <h1 class="logo">Nuxt Boilerplate</h1>
      <nav>
        <ul class="nav-links">
          <li><NuxtLink to="/">Home</NuxtLink></li>
          <li><NuxtLink to="/about">About</NuxtLink></li>
          <li><NuxtLink to="/posts">Posts</NuxtLink></li>
          <li><NuxtLink to="/showButton">Button</NuxtLink></li>
          <li><NuxtLink to="/users">Users</NuxtLink></li>
          <li><NuxtLink to="/customers">Customers</NuxtLink></li>
          <li><NuxtLink to="/todos">Todos</NuxtLink></li>
        </ul>
      </nav>
    </header>

    <main>
      <slot />
    </main>
  </div>
</template>

<style>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: #333;
  color: white;
}

.logo {
  font-size: 1.5rem;
}

.nav-links {
  list-style: none;
  display: flex;
  gap: 1rem;
  margin: 0;
  padding: 0;
}

.nav-links a {
  color: white;
  text-decoration: none;
}

.nav-links a:hover {
  text-decoration: underline;
}
</style>
