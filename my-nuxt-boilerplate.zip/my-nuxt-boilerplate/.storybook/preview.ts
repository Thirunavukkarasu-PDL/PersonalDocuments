import { setup } from "@storybook/vue3";
import { createRouter, createMemoryHistory } from "vue-router";
import { h } from "vue";
import type { Preview } from "@storybook/vue3";

import LoginForm from "../components/organisms/LoginForm.vue";
import RegistrationForm from "../components/organisms/RegistrationForm.vue";
import AuthTemplate from "../components/templates/AuthTemplate.vue";
import TodosComponent from "../components/TodosComponent.vue";

// Styles
import "../assets/css/storybook-variables.css";
import "../assets/css/button-styles.css";
import "../assets/css/forms.css";

// Set up router
const router = createRouter({
  history: createMemoryHistory(),
  routes: [
    {
      path: "/",
      component: AuthTemplate,
      children: [{ path: "", component: LoginForm }],
    },
    {
      path: "/login",
      component: AuthTemplate,
      children: [{ path: "", component: LoginForm }],
    },
    {
      path: "/register",
      component: AuthTemplate,
      children: [{ path: "", component: RegistrationForm }],
    },
    {
      path: "/todos",
      component: TodosComponent,
      children: [{ path: "", component: TodosComponent }],
    },
  ],
});

// Wait for router to be ready in Storybook
setup(async (app) => {
  app.use(router);

  // await router.isReady();
  // console.log("Storybook registered routes:");
  // router.getRoutes().forEach((route) => {
  //   console.log(`- ${route.path}`);
  // });

  console.log("Router instance in component:", router);
  console.log(
    "Routes in component:",
    router.getRoutes().map((r) => r.path)
  );

  app.component("NuxtLink", {
    props: ["to"],
    render() {
      return h(
        "a",
        {
          href: typeof this.to === "string" ? this.to : this.to.path,
          onClick: (e: MouseEvent) => {
            e.preventDefault();
            const path = typeof this.to === "string" ? this.to : this.to?.path;
            if (path) {
              router.push(path);
            }
          },
        },
        this.$slots.default?.()
      );
    },
  });

  await router.isReady();
});

const preview: Preview = {
  parameters: {
    actions: { argTypesRegex: "^on[A-Z].*" },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
  },
};

export default preview;
