/** @type { import('@storybook/vue3-vite').StorybookConfig } */
import vue from "@vitejs/plugin-vue";

export default {
  stories: [
    "../components/**/*.stories.@(js|ts|vue)",
    "../stories/**/*.stories.@(js|ts|vue)",
  ],

  addons: [
    "@storybook/addon-actions",
    "@storybook/addon-links",
    "@storybook/addon-interactions",
    "@storybook/addon-controls",
    "@storybook/addon-backgrounds",
    "@chromatic-com/storybook",
  ],

  framework: {
    name: "@storybook/vue3-vite",
    options: {},
  },

  viteFinal: async (config) => {
    config.plugins = config.plugins || [];
    config.plugins.push(vue());
    return config;
  },

  docs: {
    autodocs: true,
  },
};
